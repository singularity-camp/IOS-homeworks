//
//  NetworkManager.swift
//  IMDb
//
//  Created by Aneli  on 18.01.2024.
//

//import Foundation
//import Alamofire
//
//class NetworkManager {
//    
//    static var shared = NetworkManager()
//    
//    private let urlString: String = "https://api.themoviedb.org"
//    private let apiKey: String = "982438d6b9b34b1f632306b6c9dcce79"
//    private let session = URLSession(configuration: .default)
//    
//    private lazy var urlComponents: URLComponents = {
//        var components = URLComponents()
//        components.scheme = "https"
//        components.host = "api.themoviedb.org"
//        components.queryItems = [
//            URLQueryItem(name: "api_key", value: apiKey)
//        ]
//        return components
//    }()
//    
//    func loadMovies(completion: @escaping ([Result]) -> Void) {
//        var components = urlComponents
//        components.path = "/3/movie/now_playing"
//        
//        guard let requestUrl = components.url else {
//            return
//        }
//        
//        let task = session.dataTask(with: requestUrl) { data, response, error in
//            guard error == nil else {
//                print("Error: error calling GET")
//                return
//            }
//            
//            guard let data else {
//                print("Error: Did not recieve data")
//                return
//            }
//            
//            guard let response = response as? HTTPURLResponse, (200 ..< 300) ~= response.statusCode else {
//                print("Error: HTTP request failed")
//                return
//            }
//            
//            do {
//                let movie = try JSONDecoder().decode(Movie.self, from: data)
//                DispatchQueue.main.async {
//                    completion(movie.results)
//                }
//            } catch {
//                DispatchQueue.main.async {
//                    completion([])
//                }
//            }
//        }
//        task.resume()
//    }
//    
//    func loadGenres(completion: @escaping ([Genre]) -> Void) {
//        var components = urlComponents
//        components.path = "/3/genre/movie/list"
//        
//        guard let requestUrl = components.url else {
//            return
//        }
//        
//        AF.request(requestUrl).responseJSON { response in
//            guard let data = response.data else {
//                print("Error: Did not receive data")
//                return
//            }
//            
//            do {
//                let genresEntity = try JSONDecoder().decode(GenresEntity.self, from: data)
//                DispatchQueue.main.async {
//                    completion(genresEntity.genres)
//                }
//            } catch {
//                DispatchQueue.main.async {
//                    completion([])
//                }
//            }
//        }
//    }
//    
//    func loadMovieDetails(id: Int, completion: @escaping (MovieDetailsEntity) -> Void) {
//        var components = urlComponents
//        components.path = "/3/movie/\(id)"
//        
//        guard let requestUrl = components.url else {
//            return
//        }
//        
//        let task = session.dataTask(with: requestUrl) { data, response, error in
//            guard error == nil else {
//                print("Error: error calling GET")
//                return
//            }
//            
//            guard let data else {
//                print("Error: Did not recieve data")
//                return
//            }
//            
//            guard let response = response as? HTTPURLResponse, (200 ..< 300) ~= response.statusCode else {
//                print("Error: HTTP request failed")
//                return
//            }
//            
//            do {
//                let movieDetails = try JSONDecoder().decode(MovieDetailsEntity.self, from: data)
//                DispatchQueue.main.async {
//                    completion(movieDetails)
//                }
//            } catch {
//                DispatchQueue.main.async {
//                    print("No json!")
//                }
//            }
//        }
//        task.resume()
//    }
//    
//    func loadVideos(id: Int, completion: @escaping ([Video]) -> Void) {
//        var components = urlComponents
//        components.path = "/3/movie/\(id)/videos"
//        
//        guard let requestUrl = components.url else {
//            return
//        }
//        
//        let task = session.dataTask(with: requestUrl) { data, response, error in
//            guard error == nil else {
//                print("Error: error calling GET")
//                return
//            }
//            
//            guard let data else {
//                print("Error: Did not recieve data")
//                return
//            }
//            
//            guard let response = response as? HTTPURLResponse, (200 ..< 300) ~= response.statusCode else {
//                print("Error: HTTP request failed")
//                return
//            }
//            
//            do {
//                let videoDetails = try JSONDecoder().decode(VideoEntity.self, from: data)
//                DispatchQueue.main.async {
//                    completion(videoDetails.results)
//                }
//            } catch {
//                DispatchQueue.main.async {
//                    print("No json!")
//                }
//            }
//        }
//        task.resume()
//    }
//}
