//
//  ExternalIDs.swift
//  IMDb
//
//  Created by Aneli  on 05.02.2024.
//

import Foundation
struct ExternalIDs: Codable {
    let imdbId, facebookId, youtubeKey: String?
}
