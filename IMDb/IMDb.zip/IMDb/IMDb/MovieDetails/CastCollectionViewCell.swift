//
//  CastCollectionViewCell.swift
//  IMDb
//
//  Created by Aneli  on 05.02.2024.
//

import UIKit
import Kingfisher

class CastCollectionViewCell: UICollectionViewCell {
    private let actorImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        return imageView
    }()
    
    private let nameLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
        label.numberOfLines = 2
        return label
    }()
    
    private let roleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 12, weight: .regular)
        label.textColor = .gray
        return label
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupViews()
    }
    func configure(with castMember: CastElement) {
        if let profilePath = castMember.profilePath {
            let imageURL = URL(string: "https://image.tmdb.org/t/p/w185" + profilePath)
            actorImageView.kf.setImage(with: imageURL)
        } else {
            actorImageView.image = UIImage(named: "placeholder_actor")
        }
        nameLabel.text = castMember.name
        roleLabel.text = castMember.character
    }
    private func setupViews() {
        addSubview(actorImageView)
        addSubview(nameLabel)
        addSubview(roleLabel)
        
        actorImageView.snp.makeConstraints { make in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(100)
        }
        nameLabel.snp.makeConstraints { make in
            make.top.equalTo(actorImageView.snp.bottom).offset(4)
            make.left.right.equalToSuperview()
        }
        roleLabel.snp.makeConstraints { make in
            make.top.equalTo(nameLabel.snp.bottom).offset(2)
            make.left.right.bottom.equalToSuperview()
        }
    }
}
