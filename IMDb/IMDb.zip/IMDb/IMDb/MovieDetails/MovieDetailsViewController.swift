//
//  MovieDetailsMainViewController.swift
//  IMDb
//
//  Created by Aneli  on 18.01.2024.
//

import UIKit

class MovieDetailsViewController: UIViewController {
    var movieId: Int?
    private let networkManager = NetworkManagerAF.shared
    private var voteAverage: Int = 0
    private lazy var genres: [Genre] = [] {
        didSet {
            self.genresCollectionView.reloadData()
        }
    }
    
    private var castMembers: [CastElement] = []
    private var scrollView: UIScrollView = {
        let scroll = UIScrollView()
        scroll.showsVerticalScrollIndicator = false
        return scroll
    }()
    
    private var containerView: UIView = {
        let container = UIView()
        return container
    }()
    
    private var movieImageView: UIImageView = {
        let image = UIImageView()
        image.contentMode = .scaleAspectFill
        image.clipsToBounds = true
        return image
    }()
    
    private var titleLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 22, weight: .bold)
        return label
    }()
    
    private var voteLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        label.textColor = .systemYellow
        return label
    }()
    
    private let starsStack: UIStackView = {
        let stack = UIStackView()
        stack.alignment = .center
        stack.distribution = .fillProportionally
        stack.axis = .horizontal
        stack.spacing = 4
        return stack
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.itemSize = CGSize(width: 100, height: 150)
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.register(CastCollectionViewCell.self, forCellWithReuseIdentifier: "CastCollectionViewCell")
        collectionView.dataSource = self
        return collectionView
    }()
    
    private func createStarsStack() {
        let voteAverageDouble: Double = Double(voteAverage)
        let voteFullStars: Int = Int(voteAverageDouble / 2)
        let hasHalfStar: Bool = voteAverageDouble.truncatingRemainder(dividingBy: 2) != 0

        for _ in 0..<voteFullStars {
            let fullStarImageView = UIImageView()
            fullStarImageView.contentMode = .scaleToFill
            fullStarImageView.image = UIImage(named: "full_star")
            starsStack.addArrangedSubview(fullStarImageView)
        }

        if hasHalfStar {
            let halfStarImageView = UIImageView()
            halfStarImageView.contentMode = .scaleToFill
            halfStarImageView.image = UIImage(named: "half_star")
            starsStack.addArrangedSubview(halfStarImageView)
        }

        let leftEmptyStars: Int = 5 - voteFullStars - (hasHalfStar ? 1 : 0)
        for _ in 0..<leftEmptyStars {
            let emptyStarImageView = UIImageView()
            emptyStarImageView.contentMode = .scaleToFill
            emptyStarImageView.image = UIImage(named: "empty_star")
            starsStack.addArrangedSubview(emptyStarImageView)
        }
    }

    private var overviewLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        label.textColor = .gray
        return label
    }()
    
    private var genresCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.sectionInset = UIEdgeInsets(top: 8, left: 16, bottom: 0, right: 16)
        layout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.register(CustomCollectionViewCell.self, forCellWithReuseIdentifier: "CustomCollectionViewCell")
        return collectionView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupViews()
        loadMovieDetails()
    }
    
    private func loadMovieDetails() {
        guard let movieId = movieId else { return }
        networkManager.loadMovieDetails(id: movieId) { [weak self] movieDetails in
            self?.titleLabel.text = movieDetails.originalTitle ?? ""
            self?.overviewLabel.text = movieDetails.overview ?? ""
            if let voteAverage = movieDetails.voteAverage {
                self?.voteLabel.text = "Rating: \(voteAverage)"
                self?.voteAverage = Int(voteAverage)
                self?.createStarsStack()
            }
            self?.genres = movieDetails.genres
            
            if let backdropPath = movieDetails.posterPath {
                let urlString = "https://image.tmdb.org/t/p/original" + backdropPath
                let url = URL(string: urlString)!
                self?.movieImageView.kf.setImage(with: url)
            }
            self?.castMembers = movieDetails.cast?.cast ?? []
            self?.collectionView.reloadData()
        }
    }
    
    private func setupViews() {
        view.backgroundColor = .white
        self.title = "Movie"
        
        [scrollView].forEach {
            view.addSubview($0)
        }
        
        scrollView.addSubview(containerView)
        [movieImageView, titleLabel, voteLabel, starsStack, overviewLabel, genresCollectionView, collectionView].forEach {
            containerView.addSubview($0)
        }
        
        scrollView.snp.makeConstraints { make in
            make.edges.equalTo(view)
        }
        
        containerView.snp.makeConstraints { make in
            make.width.equalTo(view)
            make.centerX.equalTo(view)
            make.top.bottom.equalTo(scrollView)
        }
        
        movieImageView.snp.makeConstraints { make in
            make.top.equalTo(containerView).offset(100)
            make.left.equalTo(containerView).offset(33)
            make.width.equalTo(309)
            make.height.equalTo(424)
        }
        
        titleLabel.snp.makeConstraints { make in
            make.top.equalTo(movieImageView.snp.bottom).offset(16)
            make.left.right.equalTo(containerView).inset(54)
            make.height.equalTo(58)
        }
        
        voteLabel.snp.makeConstraints { make in
            make.top.equalTo(titleLabel.snp.bottom).offset(8)
            make.left.equalTo(containerView).offset(54)
            make.width.equalTo(120)
            make.height.equalTo(39.5)
        }
        
        starsStack.snp.makeConstraints { make in
            make.top.equalTo(titleLabel.snp.bottom).offset(8)
            make.left.equalTo(containerView).offset(54)
            make.height.equalTo(39.5)
        }
        
        overviewLabel.snp.makeConstraints { make in
            make.top.equalTo(starsStack.snp.bottom).offset(16)
            make.left.right.equalTo(containerView).inset(54)
        }
        
        genresCollectionView.snp.makeConstraints { make in
            make.top.equalTo(overviewLabel.snp.bottom).offset(16)
            make.left.right.equalTo(containerView).inset(54)
            make.bottom.equalTo(containerView).inset(16)
        }
        
        collectionView.snp.makeConstraints { make in
            make.top.equalTo(genresCollectionView.snp.bottom).offset(16)
            make.left.right.equalTo(containerView).inset(54)
            make.height.equalTo(150)
        }
    }
}

extension MovieDetailsViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return castMembers.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CastCollectionViewCell", for: indexPath) as! CastCollectionViewCell
        let castMember = castMembers[indexPath.item]
        cell.configure(with: castMember)
        return cell
    }
}




